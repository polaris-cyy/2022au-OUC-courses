#include "cachelab.h"
#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#define true 1
#define false 0
typedef int bool;

int address;
int size; //input 
int i, j, k; //count control
int hit, miss, evict; //output
int s, E, b, t; //arguments
int m = 64; //size of address is 64-bits
int S; //2 ^ s
char opt; // return value of getopt 
char op; // [operation] address,size

typedef struct{
	int stamp; //used to record the recently visited cache
	bool is_valid; //valid bit
	int tag; //t
}cache_line;

cache_line** cache;

void init(){//init cache, S, t, B
	S = 1 << s;
	t = m - s - b;
	cache = (cache_line**)malloc(S * sizeof(cache_line*));
	for(i = 0; i < S; ++i)
		cache[i] = (cache_line*)malloc(E * sizeof(cache_line));
	for(i = 0; i < S; ++i){
		for(j = 0; j < E; ++j){
			cache[i][j].is_valid = false;
			cache[i][j].tag = -1;
			cache[i][j].stamp = 0;
		}
	}
} 

int cur_t, cur_s;

void setCur(){
	cur_t = address >> (b + s);
	cur_s = (address>>b) & ((0xffffffff)>>(32-s));
}

void Load(){//Well... That's equivalent to Save
	int big_stamp = -1, its_index = -1;
	for(i = 0; i < E; ++i){
		if(cache[cur_s][i].stamp > big_stamp){
			big_stamp = cache[cur_s][i].stamp;
			its_index = i;
		}
		cache[cur_s][i].stamp++; //update
	}
	
	for(i = 0; i < E; ++i){
		if(cache[cur_s][i].is_valid && cache[cur_s][i].tag == cur_t){
			cache[cur_s][i].stamp = 0;
			hit++;
			return;
		}
	}
	
	miss++;
	if(cache[cur_s][its_index].is_valid)
		evict++;
	
	cache[cur_s][its_index].is_valid = true;
	cache[cur_s][its_index].stamp = 0;
	cache[cur_s][its_index].tag = cur_t;
}

int main(int argc, char* argv[])
{
    char tracefile[100] = "\0";
    
    while((opt = getopt(argc, argv, "hvs:E:b:t:")) != -1){
    	switch(opt){
    		case 's':
					s = atoi(optarg);
					break;
			case 'E':
					E = atoi(optarg);
					break;
			case 'b':
					b = atoi(optarg);
					break;
			case 't':
					strcpy(tracefile, optarg);
		}	
	}
    
    init();
    FILE*fp = fopen(tracefile, "r");
    
    while(fscanf(fp, " %c %x,%d", &op, &address, &size) > 0)
	{
		printf(" %c %x,%d", op, address, size);
		setCur();
		switch(op)
		{
			case 'L':
				Load();
				break;
			case 'M':
				Load();
				hit++;
				break;
			case 'S':
				Load();
				break; 
		}
		printf("\n");
	}
	for(i = 0; i < S; ++i)
		free(cache[i]);
	free(cache);

	printSummary(hit,miss,evict);
    return 0;
}
