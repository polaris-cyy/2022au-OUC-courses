/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
	if(M == 32 && N == 32){
		int row, column, i;
		int _0, _1, _2, _3, _4, _5, _6, _7;
		for(row = 0; row < 32; row += 8){
			for(column = 0; column < 32; column += 8){
				for(i = row; i < row + 8; ++i){
					_0 = A[i][column + 0];
					_1 = A[i][column + 1];
					_2 = A[i][column + 2];
					_3 = A[i][column + 3];
					_4 = A[i][column + 4];
					_5 = A[i][column + 5];
					_6 = A[i][column + 6];
					_7 = A[i][column + 7];
					
					B[column + 0][i] = _0;
					B[column + 1][i] = _1;
					B[column + 2][i] = _2;
					B[column + 3][i] = _3;
					B[column + 4][i] = _4;
					B[column + 5][i] = _5;
					B[column + 6][i] = _6;
					B[column + 7][i] = _7;
				}
			}
		}
	}
	else if(M == 64 && N == 64){
		int row, column, i, j;
		int _0, _1, _2, _3, _4, _5, _6, _7;
		for(row = 0; row < 64; row += 8){
			for(column = 0; column < 64; column += 8){
				for(i = row; i < row + 4; ++i){
					_0 = A[i][column + 0];
					_1 = A[i][column + 1];
					_2 = A[i][column + 2];
					_3 = A[i][column + 3];
					_4 = A[i][column + 4];
					_5 = A[i][column + 5];
					_6 = A[i][column + 6];
					_7 = A[i][column + 7];
					
					B[column+0][i+0] = _0;
					B[column+0][i+4] = _4;
					B[column+1][i+0] = _1;
					B[column+1][i+4] = _5;
					B[column+2][i+0] = _2;
					B[column+2][i+4] = _6;
					B[column+3][i+0] = _3;
					B[column+3][i+4] = _7;
 				}
 				for(j = column; j < column + 4; ++j){
					_0 = A[row + 4][j];
					_1 = A[row + 5][j];
					_2 = A[row + 6][j];
					_3 = A[row + 7][j];
					
					_4 = B[j][row + 4];
					_5 = B[j][row + 5];
					_6 = B[j][row + 6];
					_7 = B[j][row + 7];
					
					B[j][row + 4] = _0;
					B[j][row + 5] = _1;
					B[j][row + 6] = _2;
					B[j][row + 7] = _3;
					
					B[j+4][row + 0] = _4;
					B[j+4][row + 1] = _5;
					B[j+4][row + 2] = _6;
					B[j+4][row + 3] = _7;
				}
				for(j = column + 4; j < column + 8; ++j){
					_0 = A[row + 4][j];
					_1 = A[row + 5][j];
					_2 = A[row + 6][j];
					_3 = A[row + 7][j];
					
					B[j][row + 4] = _0;
					B[j][row + 5] = _1;
					B[j][row + 6] = _2;
					B[j][row + 7] = _3;
				}
 			}
 		}
 	}else if(M == 61 && N == 67){
		int i, j, m, n;
		for(i = 0; i < 61; i+=17){
			for(j = 0; j < 67; j+=17){
				for(m = i; m < (i + 17) && m < 61; ++m){
					for(n = j; n < (j + 17) && n < 67; ++n){
						B[m][n] = A[n][m];
					}
				}
			}
		}
	}
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

